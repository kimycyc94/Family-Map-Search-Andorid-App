package Request;

/**
 * ClearRequest class in the Request package
 * Clears all data
 */
public class ClearRequest {
    // Never used
}
