package Result;

//Never used-- use ParentResult
/**
 * ClearResult class in the Result package
 * Clears all data
 */
public class ClearResult extends ParentResult { }
