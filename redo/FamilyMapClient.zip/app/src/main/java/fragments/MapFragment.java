package fragments;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.*;

import com.example.familymapclient.R;
import com.google.android.gms.maps.*;
import com.google.android.gms.maps.model.*;
import android.graphics.drawable.Drawable;
import android.widget.ImageView;

import com.joanzapata.iconify.*;
import com.joanzapata.iconify.fonts.*;
import Model.*;
import async.Singleton;

import java.util.*;

public class MapFragment extends Fragment implements OnMapReadyCallback {
    private GoogleMap map;
    private View view;
    private ImageView genderView;
    private Map<String, Events> eventMarkers = new HashMap<String, Events>();


    public MapFragment() {
        // Required empty public constructor
    }

    public static MapFragment newInstance() {
        return new MapFragment();
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Iconify.with(new FontAwesomeModule());
        setHasOptionsMenu(true);
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        menu.clear();
        inflater.inflate(R.menu.menu, menu);
        super.onCreateOptionsMenu(menu, inflater);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        super.onCreateView(inflater, container, savedInstanceState);
        /*View v = inflater.inflate(R.layout.fragment_map, container, false);
        view = v;
        genderView = view.findViewById(R.id.);
        SupportMapFragment mapFragment = (SupportMapFragment) getChildFragmentManager().findFragmentById(R.id.map_fragment);
        mapFragment.getMapAsync(this);
        return view;*/
        return inflater.inflate(R.layout.fragment_map, container, false);
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        map = googleMap;
        map.setOnMarkerClickListener((GoogleMap.OnMarkerClickListener) this);
        eventMarkers = Singleton.getSingleton().getAllEvents();


        // Add a marker in Sydney and move the camera
        LatLng sydney = new LatLng(-34, 151);
        map.addMarker(new MarkerOptions().position(sydney).title("Marker in Sydney"));
        map.animateCamera(CameraUpdateFactory.newLatLng(sydney));
    }
}