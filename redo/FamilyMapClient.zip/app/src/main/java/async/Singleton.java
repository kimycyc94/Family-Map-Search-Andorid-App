package async;

import java.util.*;

import Model.*;

public class Singleton {
    private static Singleton singleton;    // Only one. Belongs to class itself. No matter where you call it, instances are the same.
    private String authToken;
    private String personID;
    private Map<String, Persons> allPersons;
    private Map<String, Events> allEvents;

    public Singleton() { }

    public static Singleton getSingleton() {
        if (singleton == null) {
            singleton = new Singleton();
        }
        return singleton;
    }

    public String getAuthToken() {
        return authToken;
    }

    public void setAuthToken(String authToken) {
        this.authToken = authToken;
    }

    public String getPersonID() {
        return personID;
    }

    public void setPersonID(String personID) {
        this.personID = personID;
    }

    public Persons getPerson(String personID) {
        try {
            return allPersons.get(personID);
            } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public Events getEvent(String eventID) {
        try {
            return allEvents.get(eventID);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public Map<String, Persons> getAllPersons() {
        return allPersons;
    }

    public void setAllPersons(Map<String, Persons> allPersons) {
        this.allPersons = allPersons;
    }

    public Map<String, Events> getAllEvents() {
        return allEvents;
    }

    public void setAllEvents(Map<String, Events> allEvents) {
        this.allEvents = allEvents;
    }
}
