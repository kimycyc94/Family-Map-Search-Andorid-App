package com.example.familymapclient;

public class PersonActivity {
}
