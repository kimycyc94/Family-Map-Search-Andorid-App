package com.example.familymapclient;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;


import android.os.Bundle;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;

import fragments.*;

public class MainActivity extends AppCompatActivity{
    public static String changeFragment;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        FragmentManager fManager = getSupportFragmentManager();
        Fragment fragment = fManager.findFragmentById(R.id.fragment_container);;

        if (getIntent().getBooleanExtra(changeFragment, false)) {
            if (fragment == null) {
                fragment = new MapFragment();
            }
        }
        else {
            if (fragment == null) {
                fragment = new LoginFragment();
            }
        }
        fManager.beginTransaction().add(R.id.fragment_container, fragment).commit();
    }
}