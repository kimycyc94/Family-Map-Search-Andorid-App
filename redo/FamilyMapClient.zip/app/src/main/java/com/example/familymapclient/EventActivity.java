package com.example.familymapclient;

public class EventActivity {
}
