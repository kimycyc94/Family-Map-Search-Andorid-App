package Request;

import Model.AuthToken;

/**
 * OnePersonRequest Class
 */
public class OnePersonRequest {
    /**
     * AuthToken
     */
    private AuthToken token;

    public OnePersonRequest() { }

    public AuthToken getToken() {
        return token;
    }

    public void setToken(AuthToken token) {
        this.token = token;
    }
}
