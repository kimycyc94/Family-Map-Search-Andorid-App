package Request;

public class ClearRequest {
    // Never used
}
