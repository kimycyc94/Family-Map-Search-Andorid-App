package Request;

import Model.AuthToken;

/**
 * OneEventRequest class
 */
public class OneEventRequest {
    /**
     * AuthToken
     */
    private AuthToken token;

    public OneEventRequest() {}

    public AuthToken getToken() {
        return token;
    }

    public void setToken(AuthToken token) {
        this.token = token;
    }
}
