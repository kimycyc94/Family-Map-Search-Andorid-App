package Model;

import java.util.Objects;
import java.util.UUID;

/**
 * Authentification Token class in Model package
 */
public class AuthToken {
    /**
     * Unique authToken string
     */
    String AuthToken;
    /**
     * user's name string
     */
    String associatedUserName;

    /**
     * AuthToken Constructor
     */
    public AuthToken() {}

    /**
     * AuthToken Constructor with AuthToken = UUID
     * @param associatedUserName
     */
    public AuthToken(String associatedUserName) {
        this.AuthToken = UUID.randomUUID().toString();
        this.associatedUserName = associatedUserName;
    }

    /**
     * AuthToken Constructor with params
     * @param AuthToken
     * @param userName
     */
    public AuthToken(String AuthToken, String userName) {
        this.AuthToken = AuthToken;
        this.associatedUserName = userName;
    }

    public String getAuthToken() {
        return AuthToken;
    }

    public void setAuthToken(String authToken) {
        AuthToken = authToken;
    }

    public String getAssociatedUserName() {
        return associatedUserName;
    }

    public void setAssociatedUserName(String associatedUserName) {
        this.associatedUserName = associatedUserName;
    }

    /**
     * @param o compare all the data members
     * @return if AuthToken's all the data members are the same, return true.
     */
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        AuthToken authToken = (AuthToken) o;
        return Objects.equals(AuthToken, authToken.AuthToken) &&
                Objects.equals(associatedUserName, authToken.associatedUserName);
    }
}
