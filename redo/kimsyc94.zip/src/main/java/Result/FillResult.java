package Result;

public class FillResult {
    /**
     * error message string
     */
    private String message;
    /**
     * successfully ran or not boolean
     */
    private boolean success;
    /**
     * user's name
     */
    private String associatedUserName;
    /**
     * how many generations do you want
     */
    private int generations;

    public FillResult(String message) {
        this.message = message;
    }

    public FillResult(String message, boolean success) {
        this.message = message;
        this.success = success;
    }

    public FillResult() { }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public boolean getSuccess() {
        return success;
    }

    public void setSuccess(boolean success) {
        this.success = success;
    }

    public String getAssociatedUserName() {
        return associatedUserName;
    }

    public void setAssociatedUserName(String associatedUserName) {
        this.associatedUserName = associatedUserName;
    }

    public int getGenerations() {
        return generations;
    }

    public void setGenerations(int generations) {
        this.generations = generations;
    }
}
