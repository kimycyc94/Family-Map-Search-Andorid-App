package Result;

import Model.Events;

public class AllEventsResult {
    /**
     * Array of event objects
     */
    private Events[] data;

    private String message;

    private boolean success;

    public AllEventsResult() { }
    /**
     * AllEventsResult constructor
     */
    public AllEventsResult(Events[] eventsArray, boolean success) {
        this.data = eventsArray;
        this.success = success;
    }

    public AllEventsResult(String message) { this.message = message; }

    public Events[] getData() {
        return data;
    }

    public void setData(Events[] data) {
        this.data = data;
    }

    public boolean isSuccess() {
        return success;
    }

    public void setSuccess(boolean success) {
        this.success = success;
    }

    public String getMessage() { return message; }

    public void setMessage(String message) { this.message = message; }
}
