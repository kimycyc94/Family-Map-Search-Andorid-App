package Result;

//Never used-- use ParentResult

public class ClearResult extends ParentResult { }
