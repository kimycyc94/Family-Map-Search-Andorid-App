package Result;

public class RegisterResult {
    /**
     * unique authToken string
     */
    private String authToken;
    /**
     * user's name
     */
    private String userName;
    /**
     * user's person ID
     */
    private String personID;

    private String message;

    /**
     * successfully ran or not boolean
     */
    private boolean success;

    public String getAuthToken() {
        return authToken;
    }

    public void setAuthToken(String authToken) {
        this.authToken = authToken;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getPersonID() {
        return personID;
    }

    public void setPersonID(String personID) {
        this.personID = personID;
    }

    public boolean isSuccess() { return success; }

    public void setSuccess(boolean success) {
        this.success = success;
    }

    public String getString() { return message; }

    public void setString(String message) {this.message = message;}

    public RegisterResult() {}

    public RegisterResult(String message) {
        this.message = message;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    /**
     * RegisterResult constructor
     */
    public RegisterResult(String authToken, String userName, String personID, boolean success) {
        this.authToken = authToken;
        this.userName = userName;
        this.personID = personID;
        this.success = success;
    }
}
