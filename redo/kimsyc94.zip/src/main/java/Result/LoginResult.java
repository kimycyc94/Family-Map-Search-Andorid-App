package Result;

public class LoginResult {
    /**
     * unique authToken string
     */
    private String authToken;
    /**
     * user's name
     */
    private String userName;
    /**
     * person's unique ID
     */
    private String personID;
    /**
     * error message string
     */
    private String message;
    /**
     * successfully ran or not boolean
     */
    private boolean success;

    /**
     * LonginResult constructor
     */
    public LoginResult(String authToken, String userName, String personID, boolean success) {
        this.authToken = authToken;
        this.userName = userName;
        this.personID = personID;
        this.success = success;
    }

    public LoginResult(String authToken, String userName, String personID, String message, boolean success) {
        this.authToken = authToken;
        this.userName = userName;
        this.personID = personID;
        this.message = message;
        this.success = success;
    }

    public LoginResult(String message, boolean success) {
        this.message = message;
        this.success = success;
    }

    public String getAuthToken() {
        return authToken;
    }

    public void setAuthToken(String authToken) {
        this.authToken = authToken;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getPersonID() {
        return personID;
    }

    public void setPersonID(String personID) {
        this.personID = personID;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public boolean getSuccess() {
        return success;
    }

    public void setSuccess(boolean success) {
        this.success = success;
    }

    /**
     * LoginResult failed
     * @param message
     */
    public LoginResult(String message) {
        this.message = message;
        success = false;
    }
}
