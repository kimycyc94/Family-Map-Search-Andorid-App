package Result;

import Model.Persons;

public class AllPersonsResult {
    /**
     * Array of event objects
     */
    private Persons[] data;

    private String message;

    private boolean success;

    public AllPersonsResult() {}
    /**
     * AllEventsResult constructor
     */
    public AllPersonsResult(Persons[] personsArray, boolean success) {
        this.data = personsArray;
        this.success = success;
    }

    public AllPersonsResult(String message) { this.message = message; }

    public Persons[] getData() {
        return data;
    }

    public void setData(Persons[] data) {
        this.data = data;
    }

    public boolean isSuccess() {
        return success;
    }

    public void setSuccess(boolean success) {
        this.success = success;
    }

    public String getMessage() { return message; }

    public void setMessage(String message) { this.message = message; }
}
