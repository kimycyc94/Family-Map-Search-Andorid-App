package com.example.familymapclient;

import org.junit.Test;
import org.junit.*;
import com.example.familymapclient.ServerProxy;

import static org.junit.Assert.*;

public class ServerProxyTest {
    ServerProxy sp;

}